package com.example.bjszerver;

import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

import java.io.IOException;
import java.net.*;
import java.util.Random;

public class HelloController {

    //@FXML private TextField tfText;
    //@FXML private ListView<String> lvList;
    @FXML private ImageView card;
    @FXML private ImageView ivSecond;
    @FXML private ImageView ivThird;
    @FXML private Circle c1;
    @FXML private Circle c2;
    @FXML private Circle c3;
    @FXML private Circle c4;
    @FXML private Circle c5;
    @FXML private Pane pnGame;
    @FXML private Button btFlip;
    @FXML private Button btHit;
    @FXML private Button btStand;
    DatagramSocket socket = null;
    int playerCount = 0;
    String value = "";
    char hsdc = 'x';
    String valueS = "";
    char hsdcS = 'x';
    int x = 0;
    int y = 0;
    int so1= 0; int ss1 = 0;
    int so2= 0; int ss2 = 0;
    int so3= 0; int ss3 = 0;
    String money = "";

    String ipF = "";

    public void initialize(){
        try {
            socket = new DatagramSocket(678);
        } catch (SocketException e) {
            e.printStackTrace();
        }
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                fogad();
            }
        });
        t.setDaemon(true);
        t.start();
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "j", "q", "t", "k"};
        char[] suits = {'h', 's', 'd', 'c'};
        Random random = new Random();
        int randRankIndex = random.nextInt(ranks.length);
        int randSuitIndex = random.nextInt(suits.length);
        String cardName = "cards/" + ranks[randRankIndex] + suits[randSuitIndex] + ".gif";
        value = ranks[randRankIndex];
        if(value.equals("j") || value.equals("q") || value.equals("t") || value.equals("k")) {ss1 = 10;} else{ss1 = Integer.parseInt(ranks[randRankIndex]);}
        //System.out.println(so1);
        hsdc = suits[randSuitIndex];
        //System.out.println(value + hsdc);
        kuld("s:"+value+hsdc, ipF, 678);
        Image cardImage = new Image(getClass().getResourceAsStream(cardName));
        card.setImage(cardImage);
        ivSecond.setImage(new ImageView(new Image(getClass().getResourceAsStream("BACK.png"))).getImage());
        ivThird.setImage(new ImageView(new Image(getClass().getResourceAsStream("cards/null.png"))).getImage());
        btHit.setDisable(false);
        btFlip.setDisable(false);
        btStand.setDisable(false);

    }

    private void fogad() {
        byte[] data = new byte[256];
        DatagramPacket packet = new DatagramPacket(data, data.length);
        while (true){
            try {
                socket.receive(packet);
                String uzenet = new String(packet.getData(), 0, packet.getLength(), "utf-8");
                String ip = packet.getAddress().getHostAddress();
                int port = packet.getPort();
                Platform.runLater(() -> onFogad(uzenet, ip, port));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    private void onFogad(String uzenet, String ip, int port){
        System.out.printf("%s -> %s\n", ip, uzenet);
        String[] s = uzenet.split(":");
        ipF = ip;
        String deposit = "";
        if(s.length>1) {
            if (s[0].equals("join")) {
                deposit = s[1];
                money = deposit;
                //System.out.printf("Joined: %s", deposit);
                kuld("joined:"+deposit, ip, port);
                playerCount++;
            }
        }
        else{
            String sy = uzenet;
            if(sy.equals("stand")){
                randomcard();
                kuld("k: " + hsdc, ip, 678);
            }
            if(sy.equals("hit")){
                randomcard();
                kuld("k: " + hsdc, ip, 678);
            }
            if (sy.equals("exit")){
                kuld("paid: " + deposit, ip, 678);
            }
        }

    }

    private void kuld(String uzenet, String ip, int port) {
        try {
            byte[] adat = uzenet.getBytes("utf-8");
            InetAddress ipv4 = Inet4Address.getByName(ip);
            DatagramPacket packet = new DatagramPacket(adat, adat.length, ipv4, port);
            socket.send(packet);
            //System.out.printf("%s:%d -> %s", ip, port, uzenet);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    int full = 0;
    @FXML void onFlipCkilck(){
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "j", "q", "t", "k"};
        char[] suits = {'h', 's', 'd', 'c'};
        Random random = new Random();
        int randRankIndex = random.nextInt(ranks.length);
        int randSuitIndex = random.nextInt(suits.length);
        valueS = ranks[randRankIndex];
        if(valueS.equals("j") || valueS.equals("q") || valueS.equals("t") || valueS.equals("k")) {ss3 = 10;} else{ss3 = Integer.parseInt(ranks[randRankIndex]);}
        //System.out.println(ss);
        hsdcS = suits[randSuitIndex];
        String sad = valueS + hsdcS;
        kuld("s: "+valueS + hsdcS+"\n", ipF, 678); // -----------------------------------
        String cardName = "cards/" + ranks[randRankIndex] + suits[randSuitIndex] + ".gif";
        Image cardImage = new Image(getClass().getResourceAsStream(cardName));
        ivSecond.setImage(cardImage);
        full = (ss1 + ss3);
        btFlip.setDisable(true);
        //kuld(" = "+full+"\n", ipF, 678); // -----------------------------------
        if (full > 17){btHit.setDisable(true);}
    }

    @FXML void onHitClick(){
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "j", "q", "t", "k"};
        char[] suits = {'h', 's', 'd', 'c'};
        Random random = new Random();
        int randRankIndex = random.nextInt(ranks.length);
        int randSuitIndex = random.nextInt(suits.length);
        valueS = ranks[randRankIndex];
        if(valueS.equals("j") || valueS.equals("q") || valueS.equals("t") || valueS.equals("k")) {ss2 = 10;} else{ss2 = Integer.parseInt(ranks[randRankIndex]);}
        //System.out.println(ss);
        hsdcS = suits[randSuitIndex];
        String cardName = "cards/" + ranks[randRankIndex] + suits[randSuitIndex] + ".gif";
        Image cardImage = new Image(getClass().getResourceAsStream(cardName));
        if(full < 17) {
            ivThird.setImage(cardImage);
            kuld("s: " + valueS + hsdcS+"\n", ipF, 678); // -----------------------------------
            full = full+ss2;
            //kuld(" = "+full+"\n", ipF, 678); // -----------------------------------
        }else{ btHit.setDisable(true); }

        // ivSecond.setImage(cardImage);
        //x = (int) ivSecond.getLayoutX();
        //y = (int) ivSecond.getLayoutY();
        //ivSecond.setX(x-20);
        //ivSecond.setY(y);
        //pnGame.getChildren().add();
        //kuld("Hit - ", "192.168.0.109", 678);
    }

    @FXML void onStandClick(){
        if(full > 17 && full < 22){
            btHit.setDisable(true);
            btFlip.setDisable(true);
            kuld("End " + money, ipF , 678);
            kuld("Balance: "+money, ipF , 678);
        }
        btHit.setDisable(true);
        btFlip.setDisable(true);
        btStand.setDisable(true);
    }

    private void blackjack(){
        //System.out.println(full);
        //kuld(" "+full+"\n", ipF, 678);
        if(full > 21){kuld("Win - Balance: " + money, ipF, 678);}
        else if(full < 21){kuld("Loose - Balance " + money, ipF, 678);}
        else if(full == 21){ kuld("BlackJack - Balance " + money, ipF, 678);}
    }

    private void randomcard(){
        String[] ranks = {"2", "3", "4", "5", "6", "7", "8", "9", "j", "q", "t", "k"};
        char[] suits = {'h', 's', 'd', 'c'};
        Random random = new Random();
        int randRankIndex = random.nextInt(ranks.length);
        int randSuitIndex = random.nextInt(suits.length);
        String cardName = "cards/" + ranks[randRankIndex] + suits[randSuitIndex] + ".gif";
        value = ranks[randRankIndex];
        if(value.equals("j") || value.equals("q") || value.equals("t") || value.equals("k")) {ss1 = 10;} else{ss1 = Integer.parseInt(ranks[randRankIndex]);}
        hsdc = suits[randSuitIndex];
    }

    @FXML void onStart(){
        kuld("Start: ", ipF, 678);
    }


    //192.168.0.109
}